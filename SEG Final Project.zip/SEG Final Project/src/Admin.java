
public class Admin extends Account {

	private Admin(String username, String name, String email, String password, String phoneNumber) {
		super(username, name, email, password, phoneNumber);
	}

}
