
package com.uottawa.shaggybremnath.segfinalproject;

public class Account {


    protected String accountNumber;
    protected static int accNumber=0;
    protected String username;
    protected String email;
    protected String name;
    protected String phoneNumber;
    protected String password;
    protected static Account[] accounts;
    protected static final int SIZE=25;
    protected int capacity;
    protected String type;

    public Account(String username, String name, String email, String phoneNumber, String password) {
        capacity= SIZE;
        accounts = new Account[capacity];
        this.name=name;
        this.username=username;
        this.email=email;
        this.phoneNumber=phoneNumber;
        this.password=password;
        accNumber++;
        accountNumber=Integer.toString(accNumber);
    }

    public void reallocate() {
        capacity*=2;
        Account[] accounts1= new Account[capacity];
        System.arraycopy(accounts, 0, accounts1, 0 , accounts.length);
        accounts=accounts1;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }
    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getPassword() {
        return password;
    }

    public String getaccNumber() {
        return accountNumber;
    }

    public String getUsername(){ return username;}

    public boolean verifyEmail(String email) {
        if (accounts == null) {
            return true;
        }
        for (int i=0; i<accounts.length;i++) {
            if(accounts[i].getEmail()==email) {
                return false;
            }
        }
        return true;
    }

    public boolean verifyUsernameAndPassword(String username, String password ) {
        if (accounts == null) {
            return true;
        }
        for (int i=0; i<accounts.length;i++) {
            if(accounts[i].getUsername()==username) {
                if(accounts[i].getPassword()==password){
                    if( accounts[i] instanceof Admin) {
                        type="admin";
                    }
                    else if (accounts[i] instanceof ServiceProvider) {
                        type="serviceProvider";
                    }
                    else if (accounts[i] instanceof HomeOwner) {
                        type="homeOwner";
                    }
                    return true;
                }
            }
        }
        return false;
    }








}