
public class HomeOwner extends Account {
	public String Address;
	public HomeOwner(String username, String name, String email, String password, String phoneNumber, String Address) {
		super(username,name, email, password, phoneNumber);
		this.Address=Address;
	}
 
}
