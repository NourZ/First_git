
public class ServiceProvider extends Account {

	public ServiceProvider(String username, String name, String email, String password, String phoneNumber) {
		super(username, name, email, password, phoneNumber);
	}

}
