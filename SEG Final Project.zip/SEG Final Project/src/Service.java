
public class Service {

	String name; 
	String 
	public Service() {
		// TODO Auto-generated constructor stub
	}
	
	

}
